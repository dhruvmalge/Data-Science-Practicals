#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sb
import statsmodels.api as stats
from plotly import graph_objects,subplots

import warnings
warnings.filterwarnings('ignore')


# In[2]:


dataset = pd.read_csv('nba_elo.csv')
dataset


# In[3]:


dataset.describe()


# In[4]:


sb.violinplot(dataset,x='total_rating',y='playoff',split=True,inner='quartile')


# In[5]:


sb.boxplot(dataset,x='total_rating',y='playoff')


# In[6]:


copy = dataset.copy()


# In[7]:


copy.pop('date')
copy.pop('playoff')
copy.pop('team1')
copy.pop('team2')


# In[8]:


sb.heatmap(copy)


# In[9]:


sb.catplot(copy,x='score1',y='score2')


# In[10]:


sb.distplot(copy)


# In[11]:


sb.lineplot(copy,x='season',y='quality')


# In[12]:


joint1 = sb.JointGrid(copy,x='quality',y='score1')
joint2 = sb.JointGrid(copy,x='quality',y='score2')
joint1.plot(sb.scatterplot,sb.histplot)
joint2.plot(sb.scatterplot,sb.histplot,alpha=.7, edgecolor=".2", linewidth=.5)
joint1.plot_marginals(sb.histplot, kde=True)


# In[13]:


sb.kdeplot(copy,x='quality',multiple='stack')


# In[14]:


sb.color_palette()


# In[15]:


sb.scatterplot(copy)


# In[16]:


sb.swarmplot(copy,x='season',y='importance')


# In[17]:


pair = sb.PairGrid(copy)
pair.map_diag(sb.histplot)
pair.map_offdiag(sb.scatterplot)


# In[18]:


pair1 = sb.PairGrid(dataset,x_vars='team1',y_vars='score1',hue='quality')
pair2 = sb.PairGrid(dataset,x_vars='team2',y_vars='score2',hue='quality')

pair1.map(sb.scatterplot)
#pair1.map_diag(sb.boxplot)
pair1.map_lower(sb.distplot)
pair1.map_upper(sb.relplot)
#pair1.map_offdiag(sb.barplot)

pair2.map(sb.scatterplot)
#pair2.map_diag(sb.boxplot)
pair2.map_lower(sb.distplot)
pair2.map_upper(sb.relplot)
#pair2.map_offdiag(sb.barplot)


# In[19]:


dataset['playoff'].unique()


# In[20]:


from plotly import graph_objects as go
from plotly import express as exp
from plotly import hist_series as hist
from plotly import subplots as subplt
from plotly import figure_factory as ff


# In[21]:


importances = [14,  54,  19,  51,  46,  66,  18,   8,   9,   5,
         0,  10,  24,  42,  13,  57,  36,  16,  12,   4,  48,
        26,  22,  45,  20,   2,  55,  31,  39,   6,  59,   1,
        38,  27,  43,   3,  64,  30,  37,  40,  11,  62,  23,
         7,  44,  33,  70,  50,  29,  35,  15,  17,  60,  34,
        69,  53,  52,  49,  58,  32,  25,  28,  72,  63,  56,
        71,  47,  41,  61,  73,  68,  21,  65,  79,  76,  77,
        78,  84,  74,  89,  67,  86,  94,  82,  87,  91, 100,
        92,  96,  99,  85,  98,  95,  81,  75,  93,  83,  90,
        97,  88]

playoff = ['t', 'q', 's', 'c', 'f', 'p']

#fig = px.line_polar(df, r='r', theta='theta', line_close=True)
#fig.update_traces(fill='toself')

figdict = dict({"type":'bar', "x":copy['quality'],"y":copy['season']})
fig = go.Figure(figdict)
fig.show()


# In[22]:


df = exp.data.gapminder()
df


# In[23]:


year = df.query("year==2007")
year


# In[24]:


for template in ["plotly", "plotly_white", "plotly_dark", "ggplot2", "seaborn", "simple_white", "none"]:
    fig = exp.scatter(year,
                     x="gdpPercap", y="lifeExp", size="pop", color="continent",
                     log_x=True, size_max=60,
                     template=template, title="Gapminder 2007: '%s' theme" % template)
    fig.show()


# In[25]:


import plotly.graph_objects as go
import pandas as pd

z_data = pd.read_csv("https://raw.githubusercontent.com/plotly/datasets/master/api_docs/mt_bruno_elevation.csv")

fig = go.Figure(
    data=go.Surface(z=z_data.values),
    layout=go.Layout(
        title="Mt Bruno Elevation",
        width=500,
        height=500,
    ))

#for template in ["plotly", "plotly_white", "plotly_dark", "ggplot2", "seaborn", "simple_white", "none"]:
fig.update_layout(template="plotly", title='Mt Bruno Elevation:')
fig.show()


# In[26]:


fig = go.Figure(go.Scatter(
    x = df['gdpPercap'],
    y = df['country']
))

fig.update_layout(xaxis = dict(tickmode = 'array',tickvals = [1, 3, 5, 7, 9, 11],ticktext = ['One', 'Three', 'Five', 'Seven', 'Nine', 'Eleven']))

fig.show()


# In[27]:


x = np.linspace(-10, 20, 100)
y = np.linspace(-30, 30, 100)
Y, X = np.meshgrid(x, y)
u = -1 - X**2 + Y
v = 1 + X - Y**2
fig = ff.create_streamline(x,y,u,v,arrow_scale=.1)
fig.show()


# In[28]:


df2 = exp.data.wind()

fig = exp.scatter_polar(df2, r="frequency", theta="direction",color='strength')
fig.show()


# In[29]:


fig = go.Figure(go.Carpet(
    a = [0,  10,  24,  42,  13,  57,  36,  16,  12,   4,  48],
    b = [38,  27,  43,   3,  64,  30,  37,  40,  11,  62,  23],
    x = [69,  53,  52,  49,  58,  32,  25,  28,  72,  63,  56],
    y = [78,  84,  74,  89,  67,  86,  94,  82,  87,  91, 100],
    aaxis = dict(
        tickprefix = 'a = ',
        smoothing = 0,
        minorgridcount = 9,
        type = 'linear'
    ),
    baxis = dict(
        tickprefix = 'b = ',
        smoothing = 0,
        minorgridcount = 9,
        type = 'linear'
    )
))

fig.show()


# In[30]:


df.columns


# In[31]:


df.values


# In[32]:


df2.columns


# In[33]:


df2.values


# In[34]:


categories = ['country', 'continent', 'year', 'lifeExp', 'pop', 'gdpPercap',
       'iso_alpha', 'iso_num']

fig = go.Figure()

fig.add_trace(go.Scatterpolar(
      r=[1, 5, 2, 2, 3],
      theta=categories,
      fill='toself',
      name='Product A'
))
fig.add_trace(go.Scatterpolar(
      r=[4, 3, 2.5, 1, 2],
      theta=categories,
      fill='toself',
      name='Product B'
))

fig.update_layout(
  polar=dict(
    radialaxis=dict(
      visible=True,
      range=[0, 5]
    )),
  showlegend=False
)

fig.show()


# In[35]:


import plotly.graph_objects as go

import networkx as nx

G = nx.random_geometric_graph(200, 0.125)

#edge create
edge_x = []
edge_y = []
for edge in G.edges():
    x0, y0 = G.nodes[edge[0]]['pos']
    x1, y1 = G.nodes[edge[1]]['pos']
    edge_x.append(x0)
    edge_x.append(x1)
    edge_x.append(None)
    edge_y.append(y0)
    edge_y.append(y1)
    edge_y.append(None)

edge_trace = go.Scatter(
    x=edge_x, y=edge_y,
    line=dict(width=0.5, color='#888'),
    hoverinfo='none',
    mode='lines')

node_x = []
node_y = []
for node in G.nodes():
    x, y = G.nodes[node]['pos']
    node_x.append(x)
    node_y.append(y)

node_trace = go.Scatter(
    x=node_x, y=node_y,
    mode='markers',
    hoverinfo='text',
    marker=dict(
        showscale=True,
        # colorscale options
        #'Greys' | 'YlGnBu' | 'Greens' | 'YlOrRd' | 'Bluered' | 'RdBu' |
        #'Reds' | 'Blues' | 'Picnic' | 'Rainbow' | 'Portland' | 'Jet' |
        #'Hot' | 'Blackbody' | 'Earth' | 'Electric' | 'Viridis' |
        colorscale='YlGnBu',
        reversescale=True,
        color=[],
        size=10,
        colorbar=dict(
            thickness=15,
            title='Node Connections',
            xanchor='left',
            titleside='right'
        ),
        line_width=2))

#create node points
node_adjacencies = []
node_text = []
for node, adjacencies in enumerate(G.adjacency()):
    node_adjacencies.append(len(adjacencies[1]))
    node_text.append('# of connections: '+str(len(adjacencies[1])))

node_trace.marker.color = node_adjacencies
node_trace.text = node_text

#create network graph

fig = go.Figure(data=[edge_trace, node_trace],
             layout=go.Layout(
                title='<br>Network graph made with Python',
                titlefont_size=16,
                showlegend=False,
                hovermode='closest',
                margin=dict(b=20,l=5,r=5,t=40),
                annotations=[ dict(
                    text="Plotly reference",
                    showarrow=False,
                    xref="paper", yref="paper",
                    x=0.005, y=-0.002 ) ],
                xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
                yaxis=dict(showgrid=False, zeroline=False, showticklabels=False))
                )
fig.show()


# In[36]:


import plotly.express as px

df = px.data.gapminder()
fig = px.scatter(df, x="gdpPercap", y="lifeExp", animation_frame="year", animation_group="country",
           size="pop", color="continent", hover_name="country",
           log_x=True, size_max=55, range_x=[100,100000], range_y=[25,90])

steps = []
for i in range(len(fig.data)):
    step = dict(
        method="update",
        args=[{"visible": [False] * len(fig.data)},
              {"title": "Slider switched to step: " + str(i)}],  # layout attribute
    )
    step["args"][0]["visible"][i] = True  # Toggle i'th trace to "visible"
    steps.append(step)

fig["layout"].pop("updatemenus")
sliders = [dict(
    active=10,
    currentvalue={"prefix": "Frequency: "},
    pad={"t": 50},
    steps=steps
)]

fig.update_layout(
    sliders=sliders
)
fig.show()


# In[37]:


import plotly.express as px
df = px.data.gapminder()
px.scatter(df, x="gdpPercap", y="lifeExp", animation_frame="year", animation_group="country",
           size="pop", color="continent", hover_name="country",
           log_x=True, size_max=55, range_x=[100,100000], range_y=[25,90])


# In[38]:


import plotly.figure_factory as ff
import plotly.express as px

df = px.data.carshare()

fig = ff.create_hexbin_mapbox(
    data_frame=df, lat="centroid_lat", lon="centroid_lon",
    nx_hexagon=10, opacity=0.5, labels={"color": "Point Count"},
    min_count=1, color_continuous_scale="Viridis",
    show_original_data=True,
    original_data_marker=dict(size=4, opacity=0.6, color="deeppink")
)
fig.update_layout(margin=dict(b=0, t=0, l=0, r=0))
fig.show()


# In[39]:


df = px.data.carshare()

fig = ff.create_hexbin_mapbox(
    data_frame=df, lat="centroid_lat", lon="centroid_lon",
    nx_hexagon=10, opacity=0.9, labels={"color": "Average Peak Hour"},
    color="peak_hour", agg_func=np.mean, color_continuous_scale="Icefire", range_color=[0,23]
)
fig.show()


# In[40]:


N = 500
n_frames = 12
lat = np.concatenate([
    np.random.randn(N) * 0.5 + np.cos(i / n_frames * 2 * np.pi) + 10
    for i in range(n_frames)
])
lon = np.concatenate([
    np.random.randn(N) * 0.5 + np.sin(i / n_frames * 2 * np.pi)
    for i in range(n_frames)
])
frame = np.concatenate([
    np.ones(N, int) * i for i in range(n_frames)
])

fig = ff.create_hexbin_mapbox(
    lat=lat, lon=lon, nx_hexagon=15, animation_frame=frame,
    color_continuous_scale="Cividis", labels={"color": "Point Count", "frame": "Period"},
    opacity=0.5, min_count=1,
    show_original_data=True, original_data_marker=dict(opacity=0.6, size=4, color="deeppink")
)
fig.update_layout(margin=dict(b=0, t=0, l=0, r=0))
fig.layout.sliders[0].pad.t=20
fig.layout.updatemenus[0].pad.t=40
fig.show()


# In[ ]:





# In[ ]:




